<%@ Page Title="Resumen" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeFile="Resumen.aspx.cs" Inherits="Resumen" %>
<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <div class="row justify-content-center">
        <div class="col-xl-9">
            <div class="card rc-card">
                <div class="card-body p-4 p-lg-5">
                    <h2 class="rc-section-title h4 mb-4"><i class="bi bi-receipt-cutoff"></i> Resumen de la reservación</h2>
                    <div class="table-responsive">
                        <table class="table table-striped rc-table align-middle">
                            <tbody>
                                <tr><th><i class="bi bi-person me-2 text-primary"></i>Nombre</th><td><asp:Label ID="lblNombre" runat="server" /></td></tr>
                                <tr><th><i class="bi bi-truck-front me-2 text-primary"></i>Tipo</th><td><span class="badge badge-soft"><asp:Label ID="lblTipo" runat="server" /></span></td></tr>
                                <tr><th><i class="bi bi-lightning-charge me-2 text-primary"></i>Quickpass</th><td><span class="badge badge-soft-success"><asp:Label ID="lblQuick" runat="server" /></span></td></tr>
                                <tr><th><i class="bi bi-calendar3 me-2 text-primary"></i>Fecha inicial</th><td><asp:Label ID="lblFecha" runat="server" /></td></tr>
                                <tr><th><i class="bi bi-clock-history me-2 text-primary"></i>Días</th><td><asp:Label ID="lblDias" runat="server" /></td></tr>
                                <tr class="table-secondary"><th><i class="bi bi-shield-check me-2"></i>Depósito garantía</th><td><asp:Label ID="lblDeposito" runat="server" /></td></tr>
                                <tr class="table-secondary"><th><i class="bi bi-cash-coin me-2"></i>Subtotal</th><td><asp:Label ID="lblSubtotal" runat="server" /></td></tr>
                                <tr class="table-secondary"><th><i class="bi bi-receipt me-2"></i>Impuestos</th><td><asp:Label ID="lblImpuestos" runat="server" /></td></tr>
                                <tr class="table-dark"><th><i class="bi bi-calculator me-2"></i>Total</th><td class="fw-bold"><asp:Label ID="lblTotal" runat="server" /></td></tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex gap-2">
                        <asp:Button ID="btnReservar" runat="server" CssClass="btn btn-success rc-btn-icon" Text="Reservar (guardar)" OnClick="btnReservar_Click" />
                        <asp:Button ID="btnVolver" runat="server" CssClass="btn btn-outline-secondary rc-btn-icon" Text="Volver" OnClick="btnVolver_Click" />
                    </div>
                    <asp:Label ID="lblMsg" runat="server" CssClass="mt-3 d-block"></asp:Label>
                </div>
            </div>
        </div>
    </div>
</asp:Content>
