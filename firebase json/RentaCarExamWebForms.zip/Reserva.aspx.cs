using System;
using System.Globalization;
public partial class Reserva : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e) { }
    protected void btnContinuar_Click(object sender, EventArgs e)
    {
        if (!Page.IsValid) return;
        Session["Nombre"] = txtNombre.Text.Trim();
        Session["Cedula"] = txtCedula.Text.Trim();
        Session["Correo"] = txtCorreo.Text.Trim();
        Session["Telefono"] = txtTelefono.Text.Trim();
        Session["Tipo"] = ddlTipo.SelectedValue;
        Session["TipoTexto"] = ddlTipo.SelectedItem.Text;
        Session["Quickpass"] = chkQuickpass.Checked ? 1 : 0;
        DateTime fi;
        if (DateTime.TryParseExact(txtFecha.Text.Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out fi))
            Session["Fecha"] = fi.ToString("yyyy-MM-dd");
        else
            Session["Fecha"] = DateTime.Parse(txtFecha.Text).ToString("yyyy-MM-dd");
        Session["Dias"] = int.Parse(txtDias.Text.Trim());
        Response.Redirect("Resumen.aspx");
    }
    protected void btnLimpiar_Click(object sender, EventArgs e)
    {
        txtNombre.Text = txtCedula.Text = txtCorreo.Text = txtTelefono.Text = txtFecha.Text = string.Empty;
        ddlTipo.SelectedIndex = 0; chkQuickpass.Checked = false; txtDias.Text = string.Empty;
    }
}
