<%@ Page Title="Reservación" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeFile="Reserva.aspx.cs" Inherits="Reserva" %>
<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <div class="row justify-content-center">
        <div class="col-xl-9">
            <div class="card rc-card">
                <div class="card-body p-4 p-lg-5">
                    <h2 class="rc-section-title h4 mb-4"><i class="bi bi-clipboard-plus"></i> Datos de reservación</h2>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Nombre</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-person"></i></span>
                                <asp:TextBox ID="txtNombre" runat="server" CssClass="form-control" />
                            </div>
                            <asp:RequiredFieldValidator ID="rfvNombre" runat="server" ControlToValidate="txtNombre" Display="Dynamic"
                                CssClass="text-danger small" ErrorMessage="El nombre es obligatorio" />
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Cédula</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-credit-card-2-front"></i></span>
                                <asp:TextBox ID="txtCedula" runat="server" CssClass="form-control" placeholder="6-0297-0081" />
                            </div>
                            <asp:RequiredFieldValidator ID="rfvCedula" runat="server" ControlToValidate="txtCedula" Display="Dynamic"
                                CssClass="text-danger small" ErrorMessage="La cédula es obligatoria" />
                            <asp:RegularExpressionValidator ID="revCedula" runat="server" ControlToValidate="txtCedula" Display="Dynamic"
                                CssClass="text-danger small" ValidationExpression="^\d-\d{4}-\d{4}$" ErrorMessage="Formato inválido (6-0297-0081)" />
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Correo</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                                <asp:TextBox ID="txtCorreo" runat="server" CssClass="form-control" TextMode="Email" />
                            </div>
                            <asp:RequiredFieldValidator ID="rfvCorreo" runat="server" ControlToValidate="txtCorreo" Display="Dynamic"
                                CssClass="text-danger small" ErrorMessage="El correo es obligatorio" />
                            <asp:RegularExpressionValidator ID="revCorreo" runat="server" ControlToValidate="txtCorreo" Display="Dynamic"
                                CssClass="text-danger small" ValidationExpression="^[^@\s]+@[^@\s]+\.[^@\s]+$" ErrorMessage="Formato de correo inválido" />
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Teléfono</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-telephone"></i></span>
                                <asp:TextBox ID="txtTelefono" runat="server" CssClass="form-control" placeholder="2204-2200" />
                            </div>
                            <asp:RequiredFieldValidator ID="rfvTelefono" runat="server" ControlToValidate="txtTelefono" Display="Dynamic"
                                CssClass="text-danger small" ErrorMessage="El teléfono es obligatorio" />
                            <asp:RegularExpressionValidator ID="revTelefono" runat="server" ControlToValidate="txtTelefono" Display="Dynamic"
                                CssClass="text-danger small" ValidationExpression="^\d{4}-\d{4}$" ErrorMessage="Formato tel. inválido (2204-2200)" />
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Tipo de vehículo</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-truck-front"></i></span>
                                <asp:DropDownList ID="ddlTipo" runat="server" CssClass="form-select">
                                    <asp:ListItem Text="Seleccione..." Value="" />
                                    <asp:ListItem Text="Sedan" Value="1" />
                                    <asp:ListItem Text="Todo terreno 2x4" Value="2" />
                                    <asp:ListItem Text="Todo terreno 4x4" Value="3" />
                                    <asp:ListItem Text="Pick up" Value="4" />
                                </asp:DropDownList>
                            </div>
                            <asp:RequiredFieldValidator ID="rfvTipo" runat="server" ControlToValidate="ddlTipo" InitialValue="" Display="Dynamic"
                                CssClass="text-danger small" ErrorMessage="Seleccione el tipo de vehículo" />
                        </div>
                        <div class="col-md-3 d-flex align-items-center">
                            <div class="form-check mt-4">
                                <asp:CheckBox ID="chkQuickpass" runat="server" CssClass="form-check-input" />
                                <label class="form-check-label" for="chkQuickpass"><i class="bi bi-lightning-charge"></i> Quickpass</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Fecha inicial</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-calendar3"></i></span>
                                <asp:TextBox ID="txtFecha" runat="server" CssClass="form-control" placeholder="dd/MM/yyyy" />
                            </div>
                            <asp:RequiredFieldValidator ID="rfvFecha" runat="server" ControlToValidate="txtFecha" Display="Dynamic"
                                CssClass="text-danger small" ErrorMessage="La fecha es obligatoria" />
                            <asp:RegularExpressionValidator ID="revFecha" runat="server" ControlToValidate="txtFecha" Display="Dynamic"
                                CssClass="text-danger small" ValidationExpression="^\d{2}/\d{2}/\d{4}$" ErrorMessage="Usa dd/MM/yyyy" />
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Días</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-clock-history"></i></span>
                                <asp:TextBox ID="txtDias" runat="server" CssClass="form-control" TextMode="Number" />
                            </div>
                            <asp:RequiredFieldValidator ID="rfvDias" runat="server" ControlToValidate="txtDias" Display="Dynamic"
                                CssClass="text-danger small" ErrorMessage="Los días son obligatorios" />
                            <asp:RangeValidator ID="rvDias" runat="server" ControlToValidate="txtDias" Display="Dynamic"
                                CssClass="text-danger small" MinimumValue="1" MaximumValue="365" Type="Integer" ErrorMessage="Valor entre 1 y 365" />
                        </div>
                    </div>
                    <div class="mt-4 d-flex gap-2">
                        <asp:ValidationSummary ID="vs" runat="server" CssClass="text-danger" />
                        <asp:Button ID="btnContinuar" runat="server" CssClass="btn btn-primary rc-btn-icon" Text="Continuar" OnClick="btnContinuar_Click" />
                        <asp:Button ID="btnLimpiar" runat="server" CssClass="btn btn-outline-secondary rc-btn-icon" Text="Limpiar" OnClick="btnLimpiar_Click" CausesValidation="false" />
                    </div>
                </div>
            </div>
        </div>
    </div>
</asp:Content>
