RentaCar (ASP.NET Web Forms) — Diseño elegante con Bootstrap 5 + Bootstrap Icons

Flujo: Default → Reserva → Resumen → Guardar.
Ajusta Web.config (ConexionRenta) y ejecuta SQL/Crear_DB_renta.sql.
La tabla usa 'Depostio' exactamente como el enunciado.
