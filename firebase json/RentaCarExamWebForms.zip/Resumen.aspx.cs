using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Globalization;

public partial class Resumen : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) CargarResumenYCalculos();
    }

    private void CargarResumenYCalculos()
    {
        string nombre = (string)Session["Nombre"];
        string tipoValor = (string)Session["Tipo"];
        string tipoTexto = (string)Session["TipoTexto"];
        int quickpass = Session["Quickpass"] != null ? Convert.ToInt32(Session["Quickpass"]) : 0;
        string fechaISO = (string)Session["Fecha"];
        int dias = Session["Dias"] != null ? Convert.ToInt32(Session["Dias"]) : 0;

        if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(tipoValor))
        {
            Response.Redirect("Reserva.aspx");
            return;
        }

        lblNombre.Text = nombre;
        lblTipo.Text = tipoTexto;
        lblQuick.Text = quickpass == 1 ? "Sí" : "No";
        DateTime fi = DateTime.ParseExact(fechaISO, "yyyy-MM-dd", CultureInfo.InvariantCulture);
        lblFecha.Text = fi.ToString("dd/MM/yyyy");
        lblDias.Text = dias.ToString();

        var ws = new WsRentaCarClient("http://maynorbarboza.somee.com/wsrentacar.asmx");
        int tipo = int.Parse(tipoValor);

        decimal deposito = ws.Deposito(tipo);
        decimal subtotal = ws.Subtotal(tipo, dias, quickpass);
        decimal impuestos = ws.Impuesto(tipo, dias);
        decimal total = deposito + subtotal + impuestos;

        lblDeposito.Text = deposito.ToString("N0", new CultureInfo("es-CR"));
        lblSubtotal.Text = subtotal.ToString("N0", new CultureInfo("es-CR"));
        lblImpuestos.Text = impuestos.ToString("N0", new CultureInfo("es-CR"));
        lblTotal.Text = total.ToString("N0", new CultureInfo("es-CR"));

        Session["Deposito"] = deposito;
        Session["Subtotal"] = subtotal;
        Session["Impuestos"] = impuestos;
        Session["Total"] = total;
    }

    protected void btnReservar_Click(object sender, EventArgs e)
    {
        try
        {
            string cs = ConfigurationManager.ConnectionStrings["ConexionRenta"].ConnectionString;
            using (var cn = new SqlConnection(cs))
            using (var cmd = cn.CreateCommand())
            {
                cmd.CommandText = @"
                    INSERT INTO Reservas
                    (Nombre, Cedula, Correo, Telefono, Tipo, Fecha, Quickpass, Dias, Depostio, Subtotal, Impuestos, Total)
                    VALUES (@Nombre, @Cedula, @Correo, @Telefono, @Tipo, @Fecha, @Quickpass, @Dias, @Deposito, @Subtotal, @Impuestos, @Total);";

                cmd.Parameters.AddWithValue("@Nombre", (string)Session["Nombre"]);
                cmd.Parameters.AddWithValue("@Cedula", (string)Session["Cedula"]);
                cmd.Parameters.AddWithValue("@Correo", (string)Session["Correo"]);
                cmd.Parameters.AddWithValue("@Telefono", (string)Session["Telefono"]);
                cmd.Parameters.AddWithValue("@Tipo", (string)Session["TipoTexto"]);
                cmd.Parameters.AddWithValue("@Fecha", DateTime.ParseExact((string)Session["Fecha"], "yyyy-MM-dd", CultureInfo.InvariantCulture));
                cmd.Parameters.AddWithValue("@Quickpass", (int)Session["Quickpass"]);
                cmd.Parameters.AddWithValue("@Dias", (int)Session["Dias"]);
                cmd.Parameters.AddWithValue("@Deposito", (decimal)Session["Deposito"]);
                cmd.Parameters.AddWithValue("@Subtotal", (decimal)Session["Subtotal"]);
                cmd.Parameters.AddWithValue("@Impuestos", (decimal)Session["Impuestos"]);
                cmd.Parameters.AddWithValue("@Total", (decimal)Session["Total"]);

                cn.Open();
                cmd.ExecuteNonQuery();
            }
            lblMsg.CssClass = "mt-3 alert alert-success";
            lblMsg.Text = "<i class='bi bi-check-circle-fill'></i> ¡Reservación guardada exitosamente!";
        }
        catch (Exception ex)
        {
            lblMsg.CssClass = "mt-3 alert alert-danger";
            lblMsg.Text = "<i class='bi bi-exclamation-triangle-fill'></i> Error al guardar: " + ex.Message;
        }
    }

    protected void btnVolver_Click(object sender, EventArgs e) { Response.Redirect("Reserva.aspx"); }
}
