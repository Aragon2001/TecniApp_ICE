using System;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) lblAlumno.Text = "Jostin Aragón Barboza";
    }
    protected void btnIr_Click(object sender, EventArgs e) { Response.Redirect("Reserva.aspx"); }
}
