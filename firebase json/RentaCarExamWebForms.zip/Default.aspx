<%@ Page Title="Introducción" Language="C#" MasterPageFile="~/Site.Master" AutoEventWireup="true" CodeFile="Default.aspx.cs" Inherits="_Default" %>
<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
    <div class="row justify-content-center">
        <div class="col-xl-8 col-lg-9">
            <div class="card rc-card">
                <div class="card-body p-4 p-lg-5">
                    <h1 class="rc-section-title h3 mb-3"><i class="bi bi-clipboard2-check-fill"></i> Examen #2 — Programación VI</h1>
                    <ul class="list-unstyled mb-4">
                        <li><i class="bi bi-building me-2 text-primary"></i><strong>Universidad:</strong> UACA</li>
                        <li><i class="bi bi-person-badge me-2 text-primary"></i><strong>Profesor:</strong> Lic. Maynor Barboza A.</li>
                        <li><i class="bi bi-person-circle me-2 text-primary"></i><strong>Alumno:</strong> <asp:Label ID="lblAlumno" runat="server" /></li>
                    </ul>
                    <div class="alert alert-info"><i class="bi bi-info-circle"></i> Sistema de reservas de Renta-Car. Presione para iniciar.</div>
                    <asp:Button ID="btnIr" runat="server" CssClass="btn btn-primary rc-btn-icon btn-lg" Text="Ir a la reservación" OnClick="btnIr_Click" />
                </div>
            </div>
        </div>
    </div>
</asp:Content>
