IF DB_ID('renta') IS NULL
BEGIN
    CREATE DATABASE renta;
END
GO

USE renta;
GO

IF OBJECT_ID('dbo.Reservas','U') IS NOT NULL
    DROP TABLE dbo.Reservas;
GO

CREATE TABLE dbo.Reservas (
    id INT IDENTITY(1,1) PRIMARY KEY,
    Nombre   CHAR(50)  NOT NULL,
    Cedula   CHAR(10)  NOT NULL,
    Correo   CHAR(50)  NOT NULL,
    Telefono CHAR(10)  NOT NULL,
    Tipo     CHAR(15)  NOT NULL,
    Fecha    DATE      NOT NULL,
    Quickpass INT      NOT NULL,
    Dias     INT       NOT NULL,
    Depostio NUMERIC(10,2) NOT NULL,
    Subtotal NUMERIC(10,2) NOT NULL,
    Impuestos NUMERIC(10,2) NOT NULL,
    Total    NUMERIC(10,2) NOT NULL
);
GO
