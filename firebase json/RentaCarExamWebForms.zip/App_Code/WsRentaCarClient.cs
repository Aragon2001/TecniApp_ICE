using System;
using System.Net;
using System.Xml;

public class WsRentaCarClient
{
    private readonly string _baseUrl;
    public WsRentaCarClient(string baseUrl){ _baseUrl = baseUrl.TrimEnd('/'); }

    public decimal Deposito(int tipo){ return CallDecimal($"{_baseUrl}/deposito?tipo={tipo}"); }
    public decimal Subtotal(int tipo, int dias, int quickpass){ return CallDecimal($"{_baseUrl}/subtotal?tipo={tipo}&dias={dias}&quickpass={quickpass}"); }
    public decimal Impuesto(int tipo, int dias){ return CallDecimal($"{_baseUrl}/impuesto?tipo={tipo}&dias={dias}"); }

    private decimal CallDecimal(string url){
        using (var wc = new WebClient()){
            string xml = wc.DownloadString(url);
            var doc = new XmlDocument(); doc.LoadXml(xml);
            var nodes = doc.GetElementsByTagName("decimal");
            if (nodes != null && nodes.Count > 0 && decimal.TryParse(nodes[0].InnerText, out decimal result))
                return result;
            throw new Exception("Respuesta inesperada del servicio.");
        }
    }
}
